<div class="account">
           <a href="home.php"><img src="./images/site/logo.png" alt="logo"></a> 
            <a href="#">My account</a>
</div>


<?php
    include $_SERVER['DOCUMENT_ROOT']. '../phpmotors/common/nav.php'
?>



