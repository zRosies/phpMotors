<nav>
                <a href="#">Home</a>
                <a href="#">Classic</a>
                <a href="#">Sports</a>
                <a href="#">Suv</a>
                <a href="#">Used</a>
</nav>

<?php



?>