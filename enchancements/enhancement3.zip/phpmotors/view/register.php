<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account | Register</title>
    <link rel="stylesheet" href="/phpmotors/css/register.css">
    <link rel="stylesheet" href="/phpmotors/css/loginmobile.css">
</head>
<body>
 <div class='weird'>
   <header>
       <?php
            include $_SERVER['DOCUMENT_ROOT']. '/phpmotors/common/header.php'
       ?>

    </header>
    <main>
        <form action="POST">
            <h1>Register</h1>
            <label for="firstName">First name <span>*</span>
                <input name=firstName id="firstName" type="text"  required placeholder="eg: Ana">
            </label>
            <label for="lastName">Last name <span>*</span>
                <input name=lastName id="lastName" type="text" required placeholder="eg: Swift">
            </label>
            <label for="email">Email <span>*</span>
                <input name=email id="email" type="email"  required placeholder="eg: yourname@gmail.com">
            </label>
            <label for="password" >Password <span>*</span>
                <input name=password id="password" type="password" required placeholder="eg: myPassword2$">
            </label>
            <p>You password must include (8) characters, (1) number, (1) capital letter, and (1) special chracter.</p>
            <button type="submit">Register</button>
        </form>

    </main>
    <footer>
                <?php

                    include $_SERVER['DOCUMENT_ROOT']. '/phpmotors/common/footer.php';

                ?>
    </footer>
    </div>
 </body>
 <script src="/phpmotors/scripts/script.js"></script>
</html>