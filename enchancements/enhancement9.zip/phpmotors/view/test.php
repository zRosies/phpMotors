<?php
 phpinfo()

?>